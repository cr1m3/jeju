$(function() {
  // scroll to the bottom
  $('#chatFlow').scrollTop($('#chatFlow')[0].scrollHeight);
});
