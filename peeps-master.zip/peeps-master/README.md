# peeps
A chat bot to help you remember the people you meet

Try it out: [daniele-peeps.herokuapp.com](https://daniele-peeps.herokuapp.com)
