<html>
    <header>
        <title>Peeps</title>
        <link href="styles/style.css" type="text/css" rel="stylesheet" />
        <link href="styles/footerstyle.css" type="text/css" rel="stylesheet" />
        <link href="styles/headerstyle.css" type="text/css" rel="stylesheet" />
    </header>
    <body>
        <?php include_once("header.php"); ?>

        <h1> Oops! </h1>
        <h2> Something terrible just happened. Sorry about that. </h2>
        <img id="fatalimage" src='https://cdn1.iconfinder.com/data/icons/emoticon-set-volume-7/512/emoticon-32-512.png'>

        <?php include_once("footer.php"); ?>
    </body>
</html>
